import { Route, Routes } from 'react-router-dom';
import AppShell from './components/AppShell';
import ComingNext from './pages/ComingNext';

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<ComingNext title="Executive overview" />} />
        <Route path="intake" element={<ComingNext title="Field intake" />} />
        <Route path="inventory-export" element={<ComingNext title="Processing and export" />} />
        <Route path="admin-hr" element={<ComingNext title="Office admin and HR" />} />
        <Route path="*" element={<ComingNext title="Page not found" />} />
      </Route>
    </Routes>
  );
}
