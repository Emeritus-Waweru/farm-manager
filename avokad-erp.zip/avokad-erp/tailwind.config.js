/** Design tokens: forest greens, cool off-white surfaces, amber and clay accents. */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        forest: { 950: '#0e2a20', 900: '#14382b', 800: '#1c4a39', 700: '#25604a', 500: '#3f8a67', 100: '#dcebe3', 50: '#eef5f1' },
        surface: { DEFAULT: '#f7f8f5', card: '#ffffff', line: '#dfe5de' },
        ink: { DEFAULT: '#18241e', soft: '#52615a' },
        amber: { 600: '#b9770e', 100: '#faecd0' },
        clay: { 600: '#a8432f', 100: '#f6dcd5' },
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
        sans: ['"Instrument Sans"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
